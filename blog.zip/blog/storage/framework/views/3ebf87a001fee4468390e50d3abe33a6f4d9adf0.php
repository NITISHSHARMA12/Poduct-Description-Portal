<section class="why_us">
    <div class="container">
        <div class="padding_30">
            <h2 class="font-2 title-2" style="text-align: center;" >Why Choose Us</h2>
            <h5 class="color-2" style="text-align: center;" >Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h5>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="about_features">
                <div class="icon animate">
                    <i class="fa fa-leaf"></i>
                </div>
                <div class="line_separator"><i class="fa fa-ellipsis-h"></i></div>
                <h4>100% Herbal</h4>
                <p>Aliquam nulla. Aenean tincidunt masl quis condimentum dictum loreme tellus cursu massa sempe Fusce pharetra sodales</p>
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="about_features">
                <div class="icon animate">
                    <i class="fa fa-heartbeat"></i>
                </div>
                <div class="line_separator"><i class="fa fa-ellipsis-h"></i></div>
                <h4>No risk of side effects</h4>
                <p>Aliquam nulla. Aenean tincidunt masl quis condimentum dictum loreme tellus cursu massa sempe Fusce pharetra sodales</p>
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="about_features">
                <div class="icon animate">
                    <i class="fa fa-hand-peace-o"></i>
                </div>
                <div class="line_separator"><i class="fa fa-ellipsis-h"></i></div>
                <h4>Lower cost</h4>
                <p>Aliquam nulla. Aenean tincidunt masl quis condimentum dictum loreme tellus cursu massa sempe Fusce pharetra sodales</p>
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="about_features">
                <div class="icon animate">
                    <i class="fa fa-arrows-alt"></i>
                </div>
                <div class="line_separator"><i class="fa fa-ellipsis-h"></i></div>
                <h4>Easy Customizable</h4>
                <p>Aliquam nulla. Aenean tincidunt masl quis condimentum dictum loreme tellus cursu massa sempe Fusce pharetra sodales</p>
            </div>
        </div>

    </div>
</section>
<?php echo $__env->make('layouts.partial.Frontend.Testimonial', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>