    <div class="side-nav-categories margin-top">
        <div class="block-title"> Categories </div>
        <div class="catageries">
            <ul class="catageries_inner">
                <?php foreach($categories as $category): ?>
                 <li><a href="<?php echo e(route('frontend.categories.show', $category['id'])); ?>"><?php echo e($category->name); ?></a></li>
                 <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div class="side-nav-categories margin-top">
        <div class="block-title-2"> <?php echo e($product->categories->first()->name); ?></div>
        <div class="catageries">
           <ul class="catageries_inner">
               <?php foreach($products as $product): ?>
               <li><a href="<?php echo e(route('frontend.products.show' ,$product->id)); ?>"><?php echo e($product->name); ?></a></li>
             <?php endforeach; ?>
           </ul>
        </div>
    </div>
