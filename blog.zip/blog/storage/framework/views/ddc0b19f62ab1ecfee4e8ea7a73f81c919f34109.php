
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' ,'placeholder' => 'Name']); ?>


    <?php echo Form::label('slug', 'Slug:'); ?>

    <?php echo Form::text('slug', null, ['class' => 'form-control' ,'placeholder' => 'slug']); ?>


    <?php echo Form::label('body', 'Body:'); ?>

    <?php echo Form::textarea('body', null, ['class' => 'form-control']); ?>



    <?php echo Form::label('thumbnail', 'Thumbnail:', ['class' => 'col-sm-2 control-label']); ?>

    <?php echo Form::file('thumbnail', ['class' => 'form-control', 'placeholder' => 'Select Thumbnail Image']); ?>

    <?php if(isset($category) && isset($category->thumbnail)): ?>
        <img src="<?php echo e(asset($category->thumbnail)); ?>" class="img-thumbnail img-responsive" style="max-width: 150px;" />
    <?php endif; ?>
