    <div class="row">
        <div class="" style="padding-bottom: 16px; text-align: center;">
            <h3>Product Details</h3>
        </div>
        <div class="col-md-8">
            <table class="table table-bordered">
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product-Id<td><?php echo e($products->p_id); ?></td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Category<td><?php foreach($products->categories as $category): ?>  <?php echo e($category->name); ?><?php endforeach; ?></td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Name<td><?php echo e($products->name); ?></td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Slug<td><?php echo e($products->slug); ?></td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Short Description<td><?php echo e($products->short_desc); ?></td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Long description<td><?php echo e($products->long_desc); ?></td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Price<td><?php echo e($products->price); ?></td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Discount<td><?php echo e($products->discount); ?></td></th>
                </tr>

            </table>
        </div>
        <div class="col-md-4">
            <img src="<?php echo e(asset($products->thumbnail)); ?>" class="img-responsive" alt="<?php echo e($products->name); ?>">
        </div>
    </div>
