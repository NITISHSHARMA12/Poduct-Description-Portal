<?php $__env->startSection('content'); ?>
    <section class="body_inner">
        <div class="container inner-page">
            <div class="col-sm-3">
                <form method="post">
                    <div class="side-nav-categories">
                        <div class="block-title"> Categories </div>
                        <div class="catageries">
                            <ul class="catageries_inner">
                               <?php foreach($categories as $id => $category): ?>
                               <li>
                                  <div class="checkbox">
                                      <label>
                                          <?php echo Form::checkbox('categories[]', $id ); ?> <?php echo e($category); ?>

                                      </label>
                                  </div>
                               </li>
                               <?php endforeach; ?>

                                <?php /*<li><a href="#">Hearbal Tea</a></li>*/ ?>
                                <?php /*<li><a href="#">Seeds</a></li>*/ ?>
                                <?php /*<li><a href="#">Essential Oils</a></li>*/ ?>
                                <?php /*<li><a href="#">Gums & resins</a></li>*/ ?>
                                <?php /*<li><a href="#">Hydosols</a></li>*/ ?>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-sm-9">
                <div class="pro-coloumn">
                    <div class="toolbar">
                        <div id="sort-by">
                            <label class="left">Sort By: </label>
                            <ul>
                                <select>
                                    <option value="volvo">Position</option>
                                    <option value="saab">Name</option>
                                    <option value="mercedes">Price</option>
                                    <option value="audi">Position</option>
                                </select>
                            </ul>
                            <a class="button-asc left" href="#" title="Set Descending Direction"><span class="top_arrow"></span></a>
                        </div>
                        <div class="pager">
                            <div class="pages">
                                <label>Page:</label>
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li class="active"><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="container-fluid">
                        <?php /*<?php foreach($products->categories as $product): ?>*/ ?>
                        <?php /*<div class="col-md-4 col-sm-6 content-inner-product">*/ ?>
                            <?php /*<div class="content-welcome content-inner">*/ ?>
                                <?php /*<div class="wc-img">*/ ?>
                                    <?php /*<img src="<?php echo e(asset($product->thumbnail)); ?>" alt="" class="img-responsive">*/ ?>
                                <?php /*</div>*/ ?>
                                <?php /*<div class="wc-c-mask text-center">*/ ?>
                                    <?php /*<div class="mask-inner">*/ ?>
                                        <?php /*<h4><?php echo e($product->name); ?></h4>*/ ?>
                                        <?php /*<div class="price-cart">*/ ?>
                                            <?php /*<strong> <i class="fa fa-inr"></i><?php echo e($product->price); ?></strong><br>*/ ?>
                                            <?php /*<a href="<?php echo e(route('frontend.products.show' ,$product->id)); ?>">View Details</a>*/ ?>
                                        <?php /*</div>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="product-slider-under-inner"><a href="#"><?php echo e($product->name); ?></a><p><i class="fa fa-inr"></i><?php echo e($product->price); ?></p></div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<?php endforeach; ?>*/ ?>

                        <?php /*<div class="col-md-4 col-sm-6 content-inner-product">*/ ?>
                            <?php /*<div class="content-welcome content-inner">*/ ?>
                                <?php /*<div class="wc-img">*/ ?>
                                    <?php /*<img src="images/product/tea.jpg" alt="" class="img-responsive">*/ ?>
                                <?php /*</div>*/ ?>
                                <?php /*<div class="wc-c-mask text-center">*/ ?>
                                    <?php /*<div class="mask-inner">*/ ?>
                                        <?php /*<h4>Beauty Cream</h4>*/ ?>
                                        <?php /*<div class="price-cart">*/ ?>
                                            <?php /*<strong> <i class="fa fa-inr"></i> 700 </strong><br>*/ ?>
                                            <?php /*<a href="shop.html">View Details</a>*/ ?>
                                        <?php /*</div>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="product-slider-under-inner"><a href="#">Aurvade Oil</a><p><i class="fa fa-inr"></i> 330</p></div>*/ ?>
                        <?php /*</div>*/ ?>

                        <?php /*<div class="col-md-4 col-sm-6 content-inner-product">*/ ?>
                            <?php /*<div class="content-welcome content-inner">*/ ?>
                                <?php /*<div class="wc-img">*/ ?>
                                    <?php /*<img src="images/product/aurvade.jpg" alt="" class="img-responsive">*/ ?>
                                <?php /*</div>*/ ?>
                                <?php /*<div class="wc-c-mask text-center">*/ ?>
                                    <?php /*<div class="mask-inner">*/ ?>
                                        <?php /*<h4>Aurvade Oil</h4>*/ ?>
                                        <?php /*<div class="price-cart">*/ ?>
                                            <?php /*<strong> <i class="fa fa-inr"></i> 700 </strong><br>*/ ?>
                                            <?php /*<a href="shop.html">View Details</a>*/ ?>
                                        <?php /*</div>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="product-slider-under-inner"><a href="#">Aurvade Oil</a><p><i class="fa fa-inr"></i> 330</p></div>*/ ?>
                        <?php /*</div>*/ ?>

                        <?php /*<div class="col-md-4 col-sm-6 content-inner-product">*/ ?>
                            <?php /*<div class="content-welcome content-inner">*/ ?>
                                <?php /*<div class="wc-img">*/ ?>
                                    <?php /*<img src="images/product/soap-and-oil.jpg" alt="" class="img-responsive">*/ ?>
                                <?php /*</div>*/ ?>
                                <?php /*<div class="wc-c-mask text-center">*/ ?>
                                    <?php /*<div class="mask-inner">*/ ?>
                                        <?php /*<h4>Hair Oil</h4>*/ ?>
                                        <?php /*<div class="price-cart">*/ ?>
                                            <?php /*<strong> <i class="fa fa-inr"></i> 700 </strong><br>*/ ?>
                                            <?php /*<a href="shop.html">View Details</a>*/ ?>
                                        <?php /*</div>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="product-slider-under-inner"><a href="#">Hair Oil</a><p><i class="fa fa-inr"></i> 700</p></div>*/ ?>
                        <?php /*</div>*/ ?>

                        <?php /*<div class="col-md-4 col-sm-6 content-inner-product">*/ ?>
                            <?php /*<div class="content-welcome content-inner">*/ ?>
                                <?php /*<div class="wc-img">*/ ?>
                                    <?php /*<img src="images/product/medicen.jpg" alt="" class="img-responsive">*/ ?>
                                <?php /*</div>*/ ?>
                                <?php /*<div class="wc-c-mask text-center">*/ ?>
                                    <?php /*<div class="mask-inner">*/ ?>
                                        <?php /*<h4>Beauty Cream</h4>*/ ?>
                                        <?php /*<div class="price-cart">*/ ?>
                                            <?php /*<strong> <i class="fa fa-inr"></i> 700 </strong><br>*/ ?>
                                            <?php /*<a href="shop.html">View Details</a>*/ ?>
                                        <?php /*</div>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="product-slider-under-inner"><a href="#">Aurvade Oil</a><p><i class="fa fa-inr"></i> 330</p></div>*/ ?>
                        <?php /*</div>*/ ?>

                        <?php /*<div class="col-md-4 col-sm-6 content-inner-product">*/ ?>
                            <?php /*<div class="content-welcome content-inner">*/ ?>
                                <?php /*<div class="wc-img">*/ ?>
                                    <?php /*<img src="images/product/tea.jpg" alt="" class="img-responsive">*/ ?>
                                <?php /*</div>*/ ?>
                                <?php /*<div class="wc-c-mask text-center">*/ ?>
                                    <?php /*<div class="mask-inner">*/ ?>
                                        <?php /*<h4>Beauty Cream</h4>*/ ?>
                                        <?php /*<div class="price-cart">*/ ?>
                                            <?php /*<strong> <i class="fa fa-inr"></i> 700 </strong><br>*/ ?>
                                            <?php /*<a href="shop.html">View Details</a>*/ ?>
                                        <?php /*</div>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</div>*/ ?>
                            <?php /*<div class="product-slider-under-inner"><a href="#">Aurvade Oil</a><p><i class="fa fa-inr"></i> 330</p></div>*/ ?>
                        <?php /*</div>*/ ?>

                    </div>


                </div>
            </div>
        </div>
    </section>
 <?php /*<?php $__env->stopSection(); ?>*/ ?>
<?php /*<?php $__env->startSection('javascript'); ?>*/ ?>
<?php /*<script>*/ ?>
    <?php /*$(document).ready(function() {*/ ?>
    <?php /*var $products = $('.grid-products'),*/ ?>
    <?php /*$filters = $("#filters input[type='checkbox']"),*/ ?>
    <?php /*product_filter = new ProductFilterLevel1($products, $filters);*/ ?>
    <?php /*product_filter.init();*/ ?>
    <?php /*});*/ ?>

    <?php /*function ProductFilterLevel1(products, filters) {*/ ?>
    <?php /*var _this = this;*/ ?>

    <?php /*this.init = function() {*/ ?>
    <?php /*this.products = products;*/ ?>
    <?php /*this.filters = filters;*/ ?>
    <?php /*this.bindEvents();*/ ?>
    <?php /*};*/ ?>

    <?php /*this.bindEvents = function() {*/ ?>
    <?php /*this.filters.click(this.filterGridProducts);*/ ?>
    <?php /*};*/ ?>

    <?php /*this.filterGridProducts = function() {*/ ?>
    <?php /*_this.products.hide();*/ ?>
    <?php /*var selectedFilters = _this.filters.filter(':checked');*/ ?>
    <?php /*if (selectedFilters.length) {*/ ?>
    <?php /*var selectedFiltersValues = [];*/ ?>
    <?php /*selectedFilters.each(function() {*/ ?>
    <?php /*var currentFilter = $(this);*/ ?>
    <?php /*selectedFiltersValues.push("[data-" + currentFilter.attr('name') + "='" + currentFilter.val() + "']");*/ ?>
    <?php /*});*/ ?>
    <?php /*_this.products.filter(selectedFiltersValues.join(',')).show();*/ ?>
    <?php /*} else {*/ ?>
    <?php /*_this.products.show();*/ ?>
    <?php /*}*/ ?>
    <?php /*};*/ ?>

    <?php /*this.removeAllFilters = function() {*/ ?>
    <?php /*_this.filters.prop('checked', false);*/ ?>
    <?php /*_this.products.show();*/ ?>
    <?php /*}*/ ?>
    <?php /*}*/ ?>
<?php /*</script>*/ ?>
<?php /*<?php $__env->stopSection(); ?>*/ ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>