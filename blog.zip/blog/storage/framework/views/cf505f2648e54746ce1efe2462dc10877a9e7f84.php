<!DOCTYPE html>
<html>
<head>
    <title>message</title>
</head>
<body>
<h3>hello<p><?php echo e($data['name']); ?></p></h3>
<h3>hello<p><?php echo e($data['email']); ?></p></h3>
<h3>hello<p><?php echo e($data['phone']); ?></p></h3>
<h3>hello<p><?php echo e($data['comment']); ?></p></h3>

</body>
</html>
