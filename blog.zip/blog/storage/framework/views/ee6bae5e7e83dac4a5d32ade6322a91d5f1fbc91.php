<?php $__env->startSection('content'); ?>
    <h1 style="text-align: center;">Update Details</h1>
    <hr>
    <div class="container">
        <?php echo Form::model($categories, ['method' => 'PATCH', 'action' => ['CategoriesController@update', $categories->id],'files' => 'true', 'role' => 'form', 'class' => 'form-horizontal']); ?>


        <?php echo Form::label('id', 'ID:'); ?>

        <?php echo Form::text('id', null, ['class' => 'form-control back-c','disabled' => 'true']); ?>


        <?php echo Form::label('name', 'Name:'); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>


        <?php echo Form::label('slug', 'Slug:'); ?>

        <?php echo Form::text('slug', null, ['class' => 'form-control' ,'placeholder' => 'slug']); ?>


        <?php echo Form::label('body', 'Body:'); ?>

        <?php echo Form::textarea('body', null, ['class' => 'form-control','rows'=>'3']); ?>


        <?php echo Form::label('thumbnail', 'Thumbnail:'); ?>

        <input type="file" class="form-control-file" name="thumbnail" id="exampleInputFile">


        <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>