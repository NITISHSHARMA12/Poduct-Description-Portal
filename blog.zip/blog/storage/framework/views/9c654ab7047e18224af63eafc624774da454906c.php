<!-- slider -->
<section id="homeFlex">
    <div class="flexslider flexFullScreen">
        <ul class="slides sliderWrapper">
            <li class="slideN0">
                <img src="<?php echo e(asset('img/slider/3.jpg')); ?>" alt="pic 1" />
                <div class="caption right">
                    <div class="element3-1" data-animation="fadeInRightBig">
                        <h1>Welcome to our online Market! </h1>
                    </div>
                    <div class="element3-2" data-animation="fadeInRightBig">
                        <h2>20% Off When You Use Your Credit Card.</h2>
                    </div>
                    <div class="element3-3 hidden-xs" data-animation="fadeInRightBig">
                        <p>DOLOR IPSUM COMMETE IPSUM COMNETUS MES.MES CUML DIA SED INENIASINGE PSUM COMNETUS MES INENIASINGE DOLOR.DOLOR IPSUME PSUM.</p>
                    </div>
                </div>
            </li>
            <li class="slideN1">
                <img src="<?php echo e(asset('img/slider/2.jpg')); ?>" alt="pic 3" />
                <div class="caption right">
                    <div class="element3-1" data-animation="fadeInLeftBig">
                        <h1>Always Fresh Vegetables.</h1>
                    </div>
                    <div class="element3-2" data-animation="fadeInRightBig">
                        <h2>DOLOR IPSUM COMMETE IPSUM COMNETUS MES.MES CUML DIA SED INENIASINGE PSUM COMNETUS MES INENIASINGE DOLOR.DOLOR IPSUME PSUM.</h2>
                    </div>
                </div>
            </li>
            <li class="slideN2">
                <img src="<?php echo e(asset('img/slider/1.jpg')); ?>" alt="pic 2" />
                <div class="caption right">
                    <div class="element3-1" data-animation="bounceInDown">
                        <h1>Big Sale</h1>
                    </div>
                    <div class="element3-2" data-animation="bounceInUp">
                        <h2>Get Up to 25% off on Beauty Products</h2>
                    </div>
                    <div class="element3-3" data-animation="bounceInUp">
                        <h2>20% flat off on health Products</h2>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</section>
<?php echo $__env->make('layouts.partial.Frontend.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>