<header class="navbar navbar-inverse navbar-fixed-top bs-docs-nav" role="banner">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="<?php echo e(route('home')); ?>" class="navbar-brand">Herbal Product</a>
        </div>
        <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
            <ul class="nav navbar-nav">
                <li>
                    <a href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">About Us <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="">About Us</a></li>
                        <li><a href="">Who We Are</a></li>
                        <li><a href="">Our Vision</a></li>
                        <li><a href="">Purpose &amp; Principles</a></li>
                        <li><a href="">Our Strategy</a></li>
                        <li><a href="">Our Leadership</a></li>
                        <li><a href="">Innovation</a></li>
                        <li><a href="">Safety &amp; Environment</a></li>
                        <li><a href="">Sustainable Living</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <?php foreach($categories as $category): ?>
                            <li><a href="<?php echo e(route('frontend.categories.show', $category['id'])); ?>"><?php echo e($category['name']); ?></a></li>
                        <?php endforeach; ?>
                        <?php /*<li><a href="#">Hearbal Tea</a></li>*/ ?>
                        <?php /*<li><a href="#">Seeds</a></li>*/ ?>
                        <?php /*<li><a href="#">Essential Oils</a></li>*/ ?>
                        <?php /*<li><a href="#">Gums & resins</a></li>*/ ?>
                        <?php /*<li><a href="#">Hydosols</a></li>*/ ?>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('contact')); ?>">Contact Us</a>
                </li>

            </ul>
        </nav>
    </div>
</header>
