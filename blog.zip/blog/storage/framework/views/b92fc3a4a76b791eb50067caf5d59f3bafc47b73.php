<?php $__env->startSection('content'); ?>
    <section class="body_inner">
        <div class="container contact_us_main" style="padding-top: 0px;">
            <div class="modal-header">
                <h4 class="modal-title"style="text-align: center">Send Your Query</h4>
            </div>
            <?php echo Form::open(['method' => 'POST', 'action' => ['EnquiryController@QuerySend'], 'role' => 'form']); ?>

                <div class="form-group" style="padding-top: 14px;">
                    <label for="p_id">Product Id</label>
                    <input type="text" name="p_id" class="form-control" value="<?php echo e($products->p_id); ?>" disabled>
                </div>
                <div class="form-group" style="   margin-bottom: 10px;">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter Your Name" required="">
                </div>
                <div class="form-group" style="   margin-bottom: 10px;">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter Your E-mail" required="">
                </div>
                <div class="form-group" style="  margin-bottom: 10px;">
                    <label for="contact">Contact Number</label>
                    <input type="text" name="contact" class="form-control" placeholder="Enter Your Contact Number" required="">
                </div>
                <div class="form-group" style="  margin-bottom: 10px;">
                    <label for="name">Product</label>
                    <input class="form-control"  type="text" name="product_name" placeholder="" value="<?php echo e($products->name); ?>" disabled>
                </div>

                <div class="form-group" style="  margin-bottom: 10px;">
                    <label for="name">Quantity</label>
                    <input type="text" name="quantity" class="form-control" placeholder="Enter Quantity">
                </div>
                <div class="form-group" style="  margin-bottom: 10px;">
                    <label for="message">Post Your Offer</label>
                    <textarea class="form-control" name="message" rows="5" placeholder="Enter Your Query" required=""></textarea>
                </div>
                <button type="submit" class="btn btn-default" style="width: 200px; padding-left: 20px;">Send</button>
            <?php echo Form::close(); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
   <script>
       $('.bs-example-modal-lg').on('hidden.bs.modal', function () {
           $('#myInput').focus()
       })
   </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>