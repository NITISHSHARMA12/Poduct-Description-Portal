<?php $__env->startSection('content'); ?>
    <div class="container" style="box-shadow: 10px 10px 10px 5px;">
        <?php echo Form::model($categories, ['method' => 'get', 'action' => ['CategoriesController@update', $categories->id], 'role' => 'form', 'class' => 'form-horizontal']); ?>


        <?php echo Form::label('id', 'ID:'); ?>

        <?php echo Form::text('id', null, ['class' => 'form-control  style-pointer','disabled' => 'true']); ?><br>

        <?php echo Form::label('name', 'Name:'); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control  style-pointer','disabled' => 'true']); ?>


        <?php echo Form::label('slug', 'Slug:'); ?>

        <?php echo Form::text('slug', null, ['class' => 'form-control' ,'placeholder' => 'slug' ,'disabled' => 'true']); ?>


        <?php echo Form::label('body', 'Body:'); ?>

        <?php echo Form::textarea('body', null, ['class' => 'form-control', 'rows'=>'3' ,'disabled' => 'true']); ?>


        <?php echo Form::label('thumbnail', 'Thumbnail:'); ?>

        <img src="<?php echo e(asset($categories->thumbnail)); ?>" class="img-responsive" alt="Responsive image">

        <a href="<?php echo e(asset('home')); ?>"><button type="button" class="btn btn-primary  form-control"> back</button></a>
        <?php echo Form::close(); ?>

        <?php $__env->stopSection(); ?>
    </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>