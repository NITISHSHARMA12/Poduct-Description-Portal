    <div class="container-fluid" style="padding-top:18px; padding-bottom:18px; margin-top: -95px">
        <div class="callout-3 wow fadeInDown animated animated">
            <div class="container">
                <div class="row">
                    <div class="col-sm-10">
                        <h3>Call Us Today At +91-7428968924 Or Email Us At <a href="#">aditya.saini@vamikatech.com</a></h3>
                        <p>Proin at ante sed quam malesuada rutrum non ut orci. Aenean ullamcorper placerat erat, et porttitor velit aliquam vitae.</p>
                    </div>
                    <div class="col-sm-2 text-right">
                        <a href="#" class="btn-round">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->make('layouts.partial.Frontend.welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <section class="padding_30">
     <div class="container-fluid no-padding">
         <div class="container">
             <h2 class="font-2" style="text-align: center;">Wide Range of our Awesome Product</h2>
             <h5 class="color-2" style="text-align: center;">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h5>
             <div class="divider ">
                 <hr class="icon" style="background-color:#dddddd;width:32%;margin-top:40px;margin-bottom:40px;"><i class="fa fa-angle-down" style="color:#bbbbbb" ;=""></i>
             </div>
         </div>

         <div class="container-fluid no-padding">
            <div class="col-sm-4 no-padding">
                <a class="block-content margin-less" href="#">
                    <img src="<?php echo e(asset('img/product/soap-and-oil.jpg')); ?>" class="img-responsive" alt="">
                    <div class="bs-text-down text-center hvr-outline-out">
                        Crude Hurbs <span>76 Product</span>
                    </div>
                </a>
            </div>
            <div class="col-sm-4 no-padding">
                <a class="block-content margin-less" href="#">
                    <img src="<?php echo e(asset('img/product/beauty.jpg')); ?>" class="img-responsive" alt="">
                    <div class="bs-text-down text-center hvr-outline-out">
                        Hearbal Tea<span>21 Product</span>
                    </div>
                </a>
            </div>

            <div class="col-sm-4 no-padding">
                <a class="block-content margin-less" href="#">
                    <img src="<?php echo e(asset('img/product/img-1.jpg')); ?>" class="img-responsive" alt="">
                    <div class="bs-text-down text-center hvr-outline-out">
                        Seeds <span>76 Product</span>
                    </div>
                </a>
            </div>

            <div class="col-sm-4 no-padding">
                <a class="block-content margin-less" href="#">
                    <img src="<?php echo e(asset('img/product/tea.jpg')); ?>" class="img-responsive" alt="">
                    <div class="bs-text-down text-center hvr-outline-out">
                        Hydosols <span>3 Product</span>
                    </div>
                </a>
            </div>

            <div class="col-sm-4 no-padding">
                <a class="block-content margin-less" href="#">
                    <img src="<?php echo e(asset('img/product/aurvade.jpg')); ?>" class="img-responsive" alt="">
                    <div class="bs-text-down text-center hvr-outline-out">
                        Essential Oils <span>76 Product</span>
                    </div>
                </a>
            </div>

            <div class="col-sm-4 no-padding">
                <a class="block-content margin-less" href="#">
                    <img src="<?php echo e(asset('img/product/medicen.jpg')); ?>" class="img-responsive" alt="">
                    <div class="bs-text-down text-center hvr-outline-out">
                        Gums &amp; resins <span>76 Product</span>
                    </div>
                </a>
            </div>

         </div>

     </div>
 </section>
    <?php echo $__env->make('layouts.partial.Frontend.recentproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>