<?php $__env->startSection('content'); ?>
    <section class="body_inner">
        <div class="container">
            <div class="col-sm-3">
                <?php echo $__env->make('layouts.partial.Frontend.Shopping.ProductList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <?php echo $__env->make('layouts.partial.Frontend.Shopping.ProductDetail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <?php echo $__env->make('layouts.partial.Frontend.Shopping.ProductDescription', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.partial.Frontend.Shopping.RelatedProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>