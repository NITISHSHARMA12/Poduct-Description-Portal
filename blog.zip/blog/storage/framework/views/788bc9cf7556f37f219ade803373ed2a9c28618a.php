<section class="padding_30">
    <div class="container">
        <div class="col-sm-4 hide-sm">
            <img src="<?php echo e(asset('img/background/png/herbs.png')); ?>" class="img-responsive" style="padding-top: 18px;" />
        </div>
        <div class="col-sm-8">
            <h1 class="font-2">Welcome</h1>
            <h4 class="color-2">TO OUR ONLINE MARKET!</h4>
            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
            <a href="http://thematicwebs.com/demo/wp/haus/about/" class="btn btn_cus btn-mini click-fade">
                Know more...
            </a>
        </div>
    </div>
</section>