
<section class="recent_add padding_30">
    <div class="container">
        <h2 class="font-2" style="text-align: center;" >Featured Products</h2>
        <h5 class="color-2" style="text-align: center;" >Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h5>
        <div class="divider ">
            <hr class="icon" style="background-color:#dddddd;width:32%;margin-top:40px;margin-bottom:40px;"><i class="fa fa-angle-down" style="color:#bbbbbb" ;=""></i>
        </div>

        <div id="owl-demo-2">
            <?php foreach($products as $product): ?>
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="<?php echo e(asset($product->thumbnail)); ?>" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4><?php echo e($product->name); ?></h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i><?php echo e($product->price); ?></strong><br>
                                    <a href="<?php echo e(route('frontend.products.show' ,$product->id)); ?>">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="<?php echo e(route('frontend.products.show' ,$product->id)); ?>"><?php echo e($product->name); ?></a><p><i class="fa fa-inr"></i><?php echo e($product->price); ?></p></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php echo $__env->make('layouts.partial.Frontend.WhyUs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>