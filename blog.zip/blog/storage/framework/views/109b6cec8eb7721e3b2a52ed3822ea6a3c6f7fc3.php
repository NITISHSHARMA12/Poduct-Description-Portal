<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 102 Template</title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Courgette" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('plugins/flexslider/flexslider.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/animation-framework/animate.min.css')); ?>"rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/owl.carousel/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('plugins/owl.carousel/owl-carousel/owl.theme.css')); ?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->
</head>
<body>
<?php echo $__env->make('layouts.partial.Header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.partial.Frontend.Slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layouts.partial.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('js/jquery.js')); ?>">jquery.js</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/owl.carousel/owl-carousel/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>" type="text/javascript" ></script>
<script src="<?php echo e(asset('js/modernizr-2.6.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('plugins/flexslider/jquery.flexslider-min.js')); ?>"></script>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
