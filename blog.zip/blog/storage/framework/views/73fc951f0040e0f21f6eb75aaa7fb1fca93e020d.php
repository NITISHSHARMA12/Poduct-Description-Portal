<?php $__env->startSection('content'); ?>
    <h1 style="text-align: center;">Update Details</h1>
    <hr>
    <div class="container">
        <?php echo Form::model($products, ['method' => 'PATCH', 'action' => ['ProductController@update', $products->id],'files' => 'true', 'role' => 'form', 'class' => 'form-horizontal']); ?>

        <?php echo $__env->make('layouts.partial.ProductForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::label('thumbnail', 'Thumbnail:', ['class' => 'col-sm-2 control-label']); ?>

        <?php echo Form::file('thumbnail', ['class' => 'form-control', 'placeholder' => 'Select Thumbnail Image']); ?>


        <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>