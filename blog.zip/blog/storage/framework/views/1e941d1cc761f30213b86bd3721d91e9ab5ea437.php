<div class="container">
    <div class="side-nav-categories">
        <div class="block-title-3"> Product Description </div>
        <div class="inner-tab">
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#description" aria-controls="description" role="tab" data-toggle="tab">Description </a></li>
                <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Specification</a></li>
                <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Attributes</a></li>
                <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Video</a></li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="description"><?php echo e($product->long_desc); ?></div>
                <div role="tabpanel" class="tab-pane" id="profile"></div>
                <div role="tabpanel" class="tab-pane" id="messages"></div>
                <div role="tabpanel" class="tab-pane" id="settings"></div>
            </div>
        </div>
    </div>
</div>
