<section class="recent_add padding_30">
    <div class="container">
        <h2 class="font-2" style="text-align: center;" >Featured Products</h2>
        <h5 class="color-2" style="text-align: center;" >Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h5>
        <div class="divider ">
            <hr class="icon" style="background-color:#dddddd;width:32%;margin-top:40px;margin-bottom:40px;"><i class="fa fa-angle-down" style="color:#bbbbbb" ;=""></i>
        </div>

        <div id="owl-demo-2">
            <div class="item">
                <div class="content-welcome">
                    <div class="wc-img">
                        <img src="<?php echo e(asset('img/product/img-1.jpg')); ?>" alt="" class="img-responsive">
                    </div>
                    <div class="wc-c-mask text-center">
                        <div class="mask-inner">
                            <h4>Rose Water</h4>
                            <div class="price-cart">
                                <strong> <i class="fa fa-inr"></i> 50 </strong><br>
                                <a href="shop.html">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-slider-under"><a href="#">Rose Water</a><p><i class="fa fa-inr"></i> 50</p></div>
            </div>
            <div class="item">
                <div class="content-welcome">
                    <div class="wc-img">
                        <img src="<?php echo e(asset('img/product/beauty.jpg')); ?>" alt="" class="img-responsive">
                    </div>
                    <div class="wc-c-mask text-center">
                        <div class="mask-inner">
                            <h4>Beauty Cream</h4>
                            <div class="price-cart">
                                <strong> <i class="fa fa-inr"></i> 700 </strong><br>
                                <a href="shop.html">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-slider-under"><a href="#">Beauty Cream</a><p><i class="fa fa-inr"></i> 700</p></div>
            </div>
            <div class="item">
                <div class="content-welcome">
                    <div class="wc-img">
                        <img src="<?php echo e(asset('img/product/soap-and-oil.jpg')); ?>" alt="" class="img-responsive">
                    </div>
                    <div class="wc-c-mask text-center">
                        <div class="mask-inner">
                            <h4>Hair Oil</h4>
                            <div class="price-cart">
                                <strong> <i class="fa fa-inr"></i> 500 </strong><br>
                                <a href="shop.html">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-slider-under"><a href="#">Hair Oil</a><p><i class="fa fa-inr"></i> 500</p></div>
            </div>
            <div class="item">
                <div class="content-welcome">
                    <div class="wc-img">
                        <img src="<?php echo e(asset('img/product/aurvade.jpg')); ?>" alt="" class="img-responsive">
                    </div>
                    <div class="wc-c-mask text-center">
                        <div class="mask-inner">
                            <h4>Aurvade Oil</h4>
                            <div class="price-cart">
                                <strong> <i class="fa fa-inr"></i> 330 </strong><br>
                                <a href="shop.html">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-slider-under"><a href="#">Aurvade Oil</a><p><i class="fa fa-inr"></i> 330</p></div>
            </div>
            <div class="item">
                <div class="content-welcome">
                    <div class="wc-img">
                        <img src="<?php echo e(asset('img/product/tea.jpg')); ?>" alt="" class="img-responsive">
                    </div>
                    <div class="wc-c-mask text-center">
                        <div class="mask-inner">
                            <h4>Green Tea</h4>
                            <div class="price-cart">
                                <strong> <i class="fa fa-inr"></i> 700 </strong><br>
                                <a href="shop.html">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-slider-under"><a href="#">Green Tea</a><p><i class="fa fa-inr"></i> 550</p></div>
            </div>
            <div class="item">
                <div class="content-welcome">
                    <div class="wc-img">
                        <img src="<?php echo e(asset('img/product/aurvade.jpg')); ?>" alt="" class="img-responsive">
                    </div>
                    <div class="wc-c-mask text-center">
                        <div class="mask-inner">
                            <h4>Hair Oil</h4>
                            <div class="price-cart">
                                <strong> <i class="fa fa-inr"></i> 900 </strong><br>
                                <a href="shop.html">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-slider-under"><a href="#">Hair Oil</a><p><i class="fa fa-inr"></i> 900</p></div>
            </div>

        </div>
    </div>
</section>
<?php echo $__env->make('layouts.partial.Frontend.WhyUs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>