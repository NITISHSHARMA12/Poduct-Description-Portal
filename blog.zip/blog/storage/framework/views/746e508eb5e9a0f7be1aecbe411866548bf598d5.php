    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' ,'placeholder' => 'Name' ,'required']); ?>


    <?php echo Form::label('slug', 'Slug:'); ?>

    <?php echo Form::text('slug', null, ['class' => 'form-control' ,'placeholder' => 'slug' ,'required']); ?>


    <?php echo Form::label('body', 'Body:'); ?>

    <?php echo Form::textarea('body', null, ['class' => 'form-control' ,'rows'=>'3' , 'placeholder'=>'body' ,'required']); ?>


    <?php echo Form::label('thumbnail', 'Thumbnail:', ['class' => 'col-sm-2 control-label']); ?>

    <?php echo Form::file('thumbnail', ['class' => 'form-control', 'placeholder' => 'Select Thumbnail Image']); ?>