<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/Admin.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-6 col-md-offset-3 pb-box " style="top:40px;">
            <div class="text-center">
				<span class="fa-stack fa-lg-high size-ci">
					<i class="fa fa-circle fa-stack-2x color-ci"></i>
					<i class="fa fa-user fa-stack-1x fa-primary"></i>
				</span>
            </div>
            <div class="adm">
                <h3>Admin Login</h3>
            </div>
            <div>

            </div>
            <div class="">
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <input type="text" class="form-control input-lg"  name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('password') ? 'has-error' :''); ?>">
                        <input type="password" class="form-control input-lg"name="password" placeholder="Password">
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <div class="">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="remember" required> Remember Me
                                </label>
                                <?php /*<?php if($errors->has('remember')): ?> <p class="help-block"><?php echo e($errors->first('remember')); ?></p> <?php endif; ?>*/ ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-lg btn-block">Sign In</button>
                        <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>
                    </div>
                </form>
            </div>
            <hr>
            <p>Don't have an account? <a href="<?php echo e(url('register')); ?>">Register Here</a></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>