<header class="navbar navbar-inverse navbar-fixed-top bs-docs-nav" role="banner">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="./" class="navbar-brand">Herbal Product</a>
        </div>
        <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
            <ul class="nav navbar-nav">
                <li>
                    <a href="#">Home</a>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">About Us <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="http://hurbs.vamikatech.com/pages/about-us">About Us</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/who-we-are">Who We Are</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/our-vision">Our Vision</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/purpose-and-principles">Purpose &amp; Principles</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/our-strategy">Our Strategy</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/our-leadership">Our Leadership</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/innovation">Innovation</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/safety-and-environment">Safety &amp; Environment</a></li>
                        <li><a href="http://hurbs.vamikatech.com/pages/sustainable-living">Sustainable Living</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Crude Hurbs</a></li>
                        <li><a href="#">Hearbal Tea</a></li>
                        <li><a href="#">Seeds</a></li>
                        <li><a href="#">Essential Oils</a></li>
                        <li><a href="#">Gums & resins</a></li>
                        <li><a href="#">Hydosols</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Contact Us</a>
                </li>

            </ul>
        </nav>
    </div>
</header>
