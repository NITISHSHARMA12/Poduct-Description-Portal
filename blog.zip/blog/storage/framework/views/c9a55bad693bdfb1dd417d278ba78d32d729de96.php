<?php $__env->startSection('content'); ?>
    <div class="container" style="box-shadow: 10px 10px 10px 5px;">
        <?php echo Form::model($products, ['method' => 'get', 'action' => ['ProductController@update', $products->id],'files' => 'true', 'role' => 'form', 'class' => 'form-horizontal']); ?>

        <?php echo $__env->make('layouts.partial.ProductForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::label('thumbnail', 'Thumbnail:', ['class' => 'control-label']); ?>

        <img src="<?php echo e(asset($products->thumbnail)); ?>" class="img-responsive" alt="Responsive image">

        <a href="<?php echo e(asset('product')); ?>"><button type="button" class="btn btn-primary  form-control"> back</button></a>
        <?php echo Form::close(); ?>

        <?php $__env->stopSection(); ?>
    </div>
<?php echo $__env->make('layouts.partial.Navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>