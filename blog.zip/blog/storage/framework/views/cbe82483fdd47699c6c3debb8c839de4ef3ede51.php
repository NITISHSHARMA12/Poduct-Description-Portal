<!DOCTYPE html>
<html>
<head>
    <title>message</title>
</head>
<body>
<?php /*<h3>hello<p><?php echo e($data['p_id']); ?></p></h3>*/ ?>
<h3>hello, dear<p><?php echo e($data['name']); ?></p></h3>
<h3>email-id<p><?php echo e($data['email']); ?></p></h3>
<?php /*<h3>hello<p><?php echo e($data['productname']); ?></p></h3>*/ ?>
<h3>contact no.<p><?php echo e($data['contact']); ?></p></h3>
<h3>order quantity <p><?php echo e($data['quantity']); ?></p></h3>
<h3>customer Query<p><?php echo e($data['message']); ?></p></h3>

</body>
</html>
