<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProducts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->string('p_id')->unique();
            $table->string('name');
            $table->string('slug');
            $table->string('category');
            $table->integer('inventory');
            $table->string('short_desc');
            $table->string('long_desc');
            $table->integer('price');
            $table->integer('discount');
            $table->string('thumbnail')->nullable();
            $table->timestamps();

            //$table->foreign('p_id')->references('id')->on('categories');
            //$table->foreign('p_id')->references('id')->on('categories')->onDelete('cascade');
        });

        Schema::create('category_product', function (Blueprint $table) {
            $table->integer('category_id')->unsigned()->index();
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
            $table->integer('product_id')->unsigned()->index();
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
        });

        Schema::create('photo_product', function (Blueprint $table) {
            $table->integer('photo_id')->unsigned()->index();
            $table->foreign('photo_id')->references('id')->on('photos')->onDelete('cascade');
            $table->integer('product_id')->unsigned()->index();
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('photo_product');
        Schema::drop('category_product');
        Schema::drop('products');
    }
}
