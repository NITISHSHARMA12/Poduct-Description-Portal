@extends('layouts.main')
@section('content')
    <section class="body_inner">
        <div class="container">
            <div class="col-sm-3">
                @include('layouts.partial.Frontend.Shopping.ProductList')
            </div>
            @include('layouts.partial.Frontend.Shopping.ProductDetail')
        </div>
        @include('layouts.partial.Frontend.Shopping.ProductDescription')
        @include('layouts.partial.Frontend.Shopping.RelatedProduct')
    </section>
@endsection()