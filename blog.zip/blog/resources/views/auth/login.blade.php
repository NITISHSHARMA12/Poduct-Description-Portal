@extends('main')
@section('css')
    <link href="{{asset('css/Admin.css')}}" rel="stylesheet">
@endsection
@section('content')
    <div class="container">
        <div class="col-md-6 col-md-offset-3 pb-box " style="top:40px;">
            <div class="text-center">
				<span class="fa-stack fa-lg-high size-ci">
					<i class="fa fa-circle fa-stack-2x color-ci"></i>
					<i class="fa fa-user fa-stack-1x fa-primary"></i>
				</span>
            </div>
            <div class="adm">
                <h3>Admin Login</h3>
            </div>
            <div>

            </div>
            <div class="">
                <form class="form-horizontal" role="form" method="POST" action="{{ url('/login') }}">
                    {!! csrf_field() !!}
                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                        <input type="text" class="form-control input-lg"  name="email" value="{{ old('email') }}" placeholder="Email">
                        @if ($errors->has('email'))
                            <span class="help-block">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group{{$errors->has('password') ? 'has-error' :''}}">
                        <input type="password" class="form-control input-lg"name="password" placeholder="Password">
                        @if ($errors->has('password'))
                            <span class="help-block">
                            <strong>{{ $errors->first('password') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <div class="">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="remember" required> Remember Me
                                </label>
                                {{--@if ($errors->has('remember')) <p class="help-block">{{ $errors->first('remember') }}</p> @endif--}}
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-lg btn-block">Sign In</button>
                        <a class="btn btn-link" href="{{ url('/password/reset') }}">Forgot Your Password?</a>
                    </div>
                </form>
            </div>
            <hr>
            <p>Don't have an account? <a href="{{url('register')}}">Register Here</a></p>
        </div>
    </div>
@endsection
