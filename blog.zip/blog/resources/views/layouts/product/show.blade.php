@extends('layouts.partial.Navbar')
@section('content')
    <div class="container" style="box-shadow: 10px 10px 10px 5px;">
        {!! Form::model($products, ['method' => 'get', 'action' => ['ProductController@show', $products->id],'files' => 'true', 'role' => 'form', 'class' => 'form-horizontal']) !!}
        @include('layouts.partial.show')
        {{--{!! Form::label('thumbnail', 'Thumbnail:', ['class' => 'control-label']) !!}--}}
        {{--<img src="{{asset($products->thumbnail)}}" class="img-responsive" alt="Responsive image">--}}

        <a href="{{asset('products')}}"><button type="button" class="btn btn-primary  form-control"> back</button></a>
        {!! Form::close() !!}
        @stop
    </div>