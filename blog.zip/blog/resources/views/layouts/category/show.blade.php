@extends('layouts.partial.Navbar')
@section('content')
    <div class="container" style="box-shadow: 10px 10px 10px 5px;">
        {!! Form::model($categories, ['method' => 'get', 'action' => ['CategoriesController@update', $categories->id], 'role' => 'form', 'class' => 'form-horizontal']) !!}

        {!! Form::label('id', 'ID:') !!}
        {!! Form::text('id', null, ['class' => 'form-control  style-pointer','disabled' => 'true'])!!}<br>

        {!! Form::label('name', 'Name:') !!}
        {!! Form::text('name', null, ['class' => 'form-control  style-pointer','disabled' => 'true']) !!}

        {!! Form::label('slug', 'Slug:') !!}
        {!! Form::text('slug', null, ['class' => 'form-control' ,'placeholder' => 'slug' ,'disabled' => 'true']) !!}

        {!! Form::label('body', 'Body:') !!}
        {!! Form::textarea('body', null, ['class' => 'form-control', 'rows'=>'3' ,'disabled' => 'true']) !!}

        {!! Form::label('thumbnail', 'Thumbnail:') !!}
        <img src="{{asset($categories->thumbnail)}}" class="img-responsive" alt="Responsive image">

        <a href="{{asset('home')}}"><button type="button" class="btn btn-primary  form-control"> back</button></a>
        {!! Form::close() !!}
        @stop
    </div>
