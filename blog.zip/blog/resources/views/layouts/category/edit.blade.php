@extends('layouts.partial.Navbar')
@section('content')
    <h1 style="text-align: center;">Update Details</h1>
    <hr>
    <div class="container">
        {!! Form::model($categories, ['method' => 'PATCH', 'action' => ['CategoriesController@update', $categories->id],'files' => 'true', 'role' => 'form', 'class' => 'form-horizontal']) !!}

        {!! Form::label('id', 'ID:') !!}
        {!! Form::text('id', null, ['class' => 'form-control back-c','disabled' => 'true'])!!}

        {!! Form::label('name', 'Name:') !!}
        {!! Form::text('name', null, ['class' => 'form-control']) !!}

        {!! Form::label('slug', 'Slug:') !!}
        {!! Form::text('slug', null, ['class' => 'form-control' ,'placeholder' => 'slug']) !!}

        {!! Form::label('body', 'Body:') !!}
        {!! Form::textarea('body', null, ['class' => 'form-control','rows'=>'3']) !!}

        {!! Form::label('thumbnail', 'Thumbnail:') !!}
        <input type="file" class="form-control-file" name="thumbnail" id="exampleInputFile">


        {!! Form::submit('Update', ['class' => 'btn btn-primary form-control']) !!}
        {!! Form::close() !!}
    </div>
@stop