<!DOCTYPE html>
<html>
<head>
    <title>message</title>
</head>
<body>
{{--<h3>hello<p>{{$data['p_id']}}</p></h3>--}}
<h3>hello, dear<p>{{$data['name']}}</p></h3>
<h3>email-id<p>{{$data['email']}}</p></h3>
{{--<h3>hello<p>{{$data['productname']}}</p></h3>--}}
<h3>contact no.<p>{{$data['contact']}}</p></h3>
<h3>order quantity <p>{{$data['quantity']}}</p></h3>
<h3>customer Query<p>{{$data['message']}}</p></h3>

</body>
</html>
