<section class="footer">
    <div class="container-fluid black_trans">
        <div class="container">
            <div class="col-sm-6">
                <div class="nice_title_white_left font-2 title-2"><h3>About Us</h3></div>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure.</p>
                <ul class="social-network social-circle">
                    <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                    <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
            <div class="col-sm-3">
                <div class="nice_title_white_left font-2 title-2"><h3 class="title-2 font-2">Product categeries</h3></div>
                <ul class="no-style-list">
                    @foreach($categories as $category)
                        <li><a href="{{route('frontend.categories.show', $category['id'])}}">{{$category['name']}}</a></li>
                    @endforeach
                </ul>
            </div>
            <div class="col-sm-3">
                <div class="nice_title_white_left font-2 title-2"><h3 class="title-2 font-2">Contact Us</h3></div>
                <p><i class="fa fa-map-marker"></i> A-55, Om Nagar, Mohan Nagar, Ghaziabad</p>
                <p><i class="fa fa-mobile-phone"></i> +91-7428968924</p>
                <p><i class="fa fa-paper-plane"></i> info@vamikatech.com</p>
                <p><i class="fa fa-globe"></i> www.herbalproduct.com</p>
            </div>
        </div>
        <div class="col-sm-3">
        </div>
    </div>
</section>