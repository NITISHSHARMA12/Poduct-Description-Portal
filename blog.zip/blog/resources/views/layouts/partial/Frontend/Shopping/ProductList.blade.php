    <div class="side-nav-categories margin-top">
        <div class="block-title"> Categories </div>
        <div class="catageries">
            <ul class="catageries_inner">
                @foreach($categories as $category)
                 <li><a href="{{ route('frontend.categories.show', $category['id'])}}">{{$category->name}}</a></li>
                 @endforeach
            </ul>
        </div>
    </div>
    <div class="side-nav-categories margin-top">
        <div class="block-title-2"> {{$product->categories->first()->name}}</div>
        <div class="catageries">
           <ul class="catageries_inner">
               @foreach($products as $product)
               <li><a href="{{ route('frontend.products.show' ,$product->id) }}">{{$product->name}}</a></li>
             @endforeach
           </ul>
        </div>
    </div>
