<div class="container">
    <div class="side-nav-categories">
        <div class="block-title-2"> Related Products </div>

        <div class="container-fluid related_product">
            <div id="owl-demo">
                @foreach($products as $product)
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="{{asset($product->thumbnail)}}" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4>{{$product->name}}</h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i> {{$product->price}} </strong><br>
                                    <a href="{{ route('frontend.products.show' ,$product->id) }}">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="{{route('frontend.products.show' ,$product->id)}}">{{$product->name}}</a><p><i class="fa fa-inr"></i>{{$product->price}}</p></div>
                </div>
                @endforeach()
                <!--
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="images/product/tea.jpg" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4>Green Tea</h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i> 700 </strong><br>
                                    <a href="shop.html">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="#">Green Tea</a><p><i class="fa fa-inr"></i> 550</p></div>
                </div>
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="images/product/img-1.jpg" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4>Rose Water</h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i> 50 </strong><br>
                                    <a href="shop.html">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="#">Rose Water</a><p><i class="fa fa-inr"></i> 50</p></div>
                </div>
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="images/product/beauty.jpg" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4>Beauty Cream</h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i> 700 </strong><br>
                                    <a href="shop.html">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="#">Beauty Cream</a><p><i class="fa fa-inr"></i> 700</p></div>
                </div>
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="images/product/soap-and-oil.jpg" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4>Hair Oil</h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i> 500 </strong><br>
                                    <a href="shop.html">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="#">Hair Oil</a><p><i class="fa fa-inr"></i> 500</p></div>
                </div>
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="images/product/aurvade.jpg" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4>Hair Oil</h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i> 900 </strong><br>
                                    <a href="shop.html">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="#">Hair Oil</a><p><i class="fa fa-inr"></i> 900</p></div>
                </div>-->
            </div>
        </div>
    </div>
</div>