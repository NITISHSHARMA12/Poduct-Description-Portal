<section class="body_inner">
    <div class="container">
        <div class="side-nav-categories">
            <div class="block-title-2"> Receant Products </div>
            <div class="container-fluid related_product">
                <div id="owl-demo">
                    @foreach($recentproducts as $rproduct)
                        <div class="item">
                            <div class="content-welcome">
                                <div class="wc-img">
                                    <img src="{{asset($rproduct->thumbnail)}}" alt="" class="img-responsive">
                                </div>
                                <div class="wc-c-mask text-center">
                                    <div class="mask-inner">
                                        <h4>{{$rproduct->name}}</h4>
                                        <div class="price-cart">
                                            <strong> <i class="fa fa-inr"></i> {{$rproduct->price}} </strong><br>
                                            <a href="{{ route('frontend.products.show' ,$rproduct->id) }}">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="product-slider-under"><a href="{{route('frontend.products.show' ,$rproduct->id)}}">{{$rproduct->name}}</a><p><i class="fa fa-inr"></i>{{$rproduct->price}}</p></div>
                        </div>
                    @endforeach()
                </div>
            </div>
        </div>
    </div>
</section>
  