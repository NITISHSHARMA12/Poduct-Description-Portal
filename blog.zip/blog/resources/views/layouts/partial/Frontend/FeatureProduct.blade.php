
<section class="recent_add padding_30">
    <div class="container">
        <h2 class="font-2" style="text-align: center;" >Featured Products</h2>
        <h5 class="color-2" style="text-align: center;" >Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h5>
        <div class="divider ">
            <hr class="icon" style="background-color:#dddddd;width:32%;margin-top:40px;margin-bottom:40px;"><i class="fa fa-angle-down" style="color:#bbbbbb" ;=""></i>
        </div>

        <div id="owl-demo-2">
            @foreach($products as $product)
                <div class="item">
                    <div class="content-welcome">
                        <div class="wc-img">
                            <img src="{{asset($product->thumbnail)}}" alt="" class="img-responsive">
                        </div>
                        <div class="wc-c-mask text-center">
                            <div class="mask-inner">
                                <h4>{{$product->name}}</h4>
                                <div class="price-cart">
                                    <strong> <i class="fa fa-inr"></i>{{$product->price}}</strong><br>
                                    <a href="{{route('frontend.products.show' ,$product->id)}}">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-slider-under"><a href="{{route('frontend.products.show' ,$product->id)}}">{{$product->name}}</a><p><i class="fa fa-inr"></i>{{$product->price}}</p></div>
                </div>
            @endforeach()
        </div>
    </div>
</section>
@include('layouts.partial.Frontend.WhyUs')