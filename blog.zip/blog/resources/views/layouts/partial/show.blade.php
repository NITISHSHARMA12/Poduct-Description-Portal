    <div class="row">
        <div class="" style="padding-bottom: 16px; text-align: center;">
            <h3>Product Details</h3>
        </div>
        <div class="col-md-8">
            <table class="table table-bordered">
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product-Id<td>{{$products->p_id}}</td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Category<td>@foreach($products->categories as $category)  {{$category->name}}@endforeach()</td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Name<td>{{$products->name}}</td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Slug<td>{{$products->slug}}</td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Short Description<td>{{$products->short_desc}}</td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Long description<td>{{$products->long_desc}}</td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Price<td>{{$products->price}}</td></th>
                </tr>
                <tr>
                    <th style="background-color: rgba(245, 245, 220, 0.31);">Product Discount<td>{{$products->discount}}</td></th>
                </tr>

            </table>
        </div>
        <div class="col-md-4">
            <img src="{{asset($products->thumbnail)}}" class="img-responsive" alt="{{$products->name}}">
        </div>
    </div>
