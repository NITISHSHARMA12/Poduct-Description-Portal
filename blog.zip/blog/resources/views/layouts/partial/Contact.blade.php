@extends('layouts.main')
@section('content')
    <section class="body_inner">
        <div class="container contact_us_main">
            <div class="container">
                <h2 class="font-2" style="text-align: center;">We are happy to help you</h2>
                <div class="divider ">
                    <hr class="icon" style="background-color:#dddddd;width:32%;margin-top:40px;margin-bottom:40px;"><i class="fa fa-angle-down" style="color:#bbbbbb" ;=""></i>
                </div>
            </div>
            <div class="container-fluid">
                <div class="col-sm-6 contact_us_map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3571.920147940429!2d80.3477163144448!3d26.458302785874682!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399c475b4e0f3589%3A0x627d52d5bb2c4dc7!2sNature+Herbs!5e0!3m2!1sen!2sin!4v1452501766101" width="600" height="340" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
                <div class="col-sm-6">
                    <h3 class="font_2 text_shadow_txt">Contact Us</h3>
                    <div class="title-bottom-1"></div>
                    <ul class="contact_us_page_list">
                        <li><h4 class="text_shadow_txt"><i class="fa fa-map-marker"></i>&nbsp;&nbsp;&nbsp; <strong>Address :</strong></h4> <p>G-3,Pankaj Chember, Preet Vihar Comm.Complex, Delhi-110092</p></li>
                        <li><h4 class="text_shadow_txt"><i class="fa fa-phone"></i>&nbsp;&nbsp;&nbsp; <strong>Contact No :</strong></h4>  <p>9810781284, 9310781284, 43082000</p></li>
                        <li><h4 class="text_shadow_txt"><i class="fa fa-envelope-o"></i>&nbsp;&nbsp;&nbsp; <strong>Mail ID :</strong></h4>  <p>gauravmotorspv@carmazic.com</p></li>
                    </ul>
                </div>
            </div>

            <div class="container-fluid" style="padding-top: 30px;">
                <h3 class="font_2 text_shadow_txt">Drop Your Query</h3>
                <div class="title-bottom-1" style="margin-bottom: 20px;"></div>
                {!! Form::open(['method' => 'POST', 'action' => ['EnquiryController@user'], 'role' => 'form']) !!}
                    <div class="col-sm-6">

                        <div class="form-group">
                            <label for="exampleInputName1">Your Name</label>
                            <input type="text" class="form-control form-control-custome" name="name" id="exampleInputName1" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" class="form-control form-control-custome" name="email" id="exampleInputEmail1" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputNo1">Contact no</label>
                            <input type="text" class="form-control form-control-custome" name="phone" id="exampleInputNo1" placeholder="Contact no" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="exampleInputmassage1">Your Query</label>
                            <textarea class="form-control form-control-custome" rows="8" name="comment" id="exampleInputmassage1" placeholder="Your Massage" required></textarea>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-default">Submit</button>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </section>
  @endsection