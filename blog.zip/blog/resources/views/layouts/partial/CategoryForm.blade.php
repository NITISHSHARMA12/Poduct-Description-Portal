    {!! Form::label('name', 'Name:') !!}
    {!! Form::text('name', null, ['class' => 'form-control' ,'placeholder' => 'Name' ,'required']) !!}

    {!! Form::label('slug', 'Slug:') !!}
    {!! Form::text('slug', null, ['class' => 'form-control' ,'placeholder' => 'slug' ,'required']) !!}

    {!! Form::label('body', 'Body:') !!}
    {!! Form::textarea('body', null, ['class' => 'form-control' ,'rows'=>'3' , 'placeholder'=>'body' ,'required']) !!}

    {!! Form::label('thumbnail', 'Thumbnail:', ['class' => 'col-sm-2 control-label']) !!}
    {!! Form::file('thumbnail', ['class' => 'form-control', 'placeholder' => 'Select Thumbnail Image']) !!}