@extends('layouts.main')
@include('layouts.partial.Frontend.Slider')