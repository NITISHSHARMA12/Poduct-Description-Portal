$(document).ready(function(){
    $("#name").keyup(function(){
        var Text = $(this).val();
        Text = Text.toLowerCase();
        Text = Text.replace(/[^a-z0-9-]/gi, '-').

            replace(/^-|-$/g, '');
        $("#slug").val(Text);
    });
});