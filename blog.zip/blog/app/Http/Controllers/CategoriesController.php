<?php

namespace App\Http\Controllers;
use App\Category;
use App\Http\Requests\Categories;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class CategoriesController extends Controller
{
    public function __construct(){
        $this->middleware('auth');

    }
    public function index(){
        $categories=Category::all();
        return view('layouts.category.index',compact('categories'));
    }
    public function create(){
        return view('layouts.category.create');
    }
    public function store(Categories $request)
    {
        $category = new Category($request->all());
        $category->save();
        $file = $request->file('thumbnail');
        $category->save();
        $category->saveThumbnail($request->file('thumbnail'));
        flash()->success('You Category  has been created.');
        return redirect('home');
    }

    public function show($id)
    {
        $categories=Category::findOrFail($id);
        return view('layouts.category.show', compact('categories'));
    }

    public function edit($id)
    {
        $categories=Category::findOrFail($id);
        return view('layouts.category.edit', compact('categories'));
    }

    public function update($id, Categories $request)
    {

        $category=Category::findOrFail($id);
        $category->update($request->all());
        $category->saveThumbnail($request->file('thumbnail'));
        flash()->success('You Category has been Update');
        return redirect('home');
    }

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id)
    {
        $category=Category::findOrFail($id);
        $category->delete($id);
       flash()->error('You Category has been Update');
        return redirect('home');
    }

}
