<?php

namespace App\Http\Controllers;
use App\Category;
use App\Http\Requests\ProductRequest;
use App\Product;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

class ProductController extends Controller
{
    public function __construct(){
        $this->middleware('auth');

    }
    public function index(){
        $products =Product::all();
        return view('layouts.product.index',compact('products'));
    }
    public function create(){
        $categories = Category::lists('name', 'id');
       // dd($categories);
        return view('layouts.product.create', compact('categories'));
    }
    public function store(ProductRequest $request){
        //dd($request->all());
        $product = new product($request->all());
        $product->save();
        $file = $request->file('thumbnail');
        $product->save();
        $product->saveThumbnail($request->file('thumbnail'));
        if ($request->has('categories')) {
            $product->categories()->attach($request->get('categories'));
        }
        flash()->overlay('You product has been created.');
        return redirect('products');
    }
    public function show($id){
        $products=Product::findOrFail($id);
        //$products =Product::all();
        return view('layouts.product.show' , compact('products'));
    }
    public function edit($id){
        $categories=Category::lists('name','id');
        $products=Product::findOrFail($id);

        return view('layouts.product.edit' , compact('products','categories'));
    }
    public function update($id , ProductRequest $request){
        $product=Product::findOrFail($id);
        $product->update($request->all());
        $product->saveThumbnail($request->file('thumbnail'));
        if ($request->has('categories')) {
            $product->categories()->sync($request->get('categories'));
        }
        flash()->success('You product has been Update.');
        return redirect('products');
    }
    public function destroy($id){
        $products=Product::findOrFail($id);
        $products->delete($id);
        flash()->success('You product has been Deleted.');
        return redirect('products');
    }
}
