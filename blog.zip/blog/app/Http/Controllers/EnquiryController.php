<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\UserRequest;
use App\Mailers\AdminMailer;
use App\Product;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class EnquiryController extends Controller
{
    public function __construct(AdminMailer $mailer)
    {
        $this->mailer = $mailer;
    }
    public function contact(){
        $categories=Category::all();
        return view('layouts.partial.contact',compact('categories'));
    }
    public function user(UserRequest $request)
    {
        $this->mailer->SendUserData($request->all())->deliver();
        return redirect()->back()->with('message', 'You Message has been send.');
//        dd(message);
    }
    public function query($id)
    {
        $products=Product::findOrFail($id);
//        dd($products);
         $categories=Category::all();
        return view('layouts.partial.Frontend.Shopping.EnquiryForm',compact('categories','products'));
    }
    public function QuerySend(Request $request)
    {

        $this->mailer->sendUserProductData($request->all())->deliver();
        return redirect('/')->with('message', 'You Message has been send.');

//        dd(message);
    }
}
