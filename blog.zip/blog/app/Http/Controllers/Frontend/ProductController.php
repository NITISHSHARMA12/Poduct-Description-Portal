<?php

namespace App\Http\Controllers\Frontend;

use App\Product;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Category;

class ProductController extends Controller
{
    public function index(){
        $products=Product::all();
        return view('home',compact('products'));
    }
    public function show($id){
        $product=Product::with('categories')->where('id', $id)->firstOrFail();
//        dd($product->name);
        $categories=Category::all();
        $category= $product->categories->first();
        $rproducts = null;
        $rcategory = $product->categories->first();
        if (isset($rcategory)) {
            $rproducts = $rcategory->product()->get();
        }
        //dd($rproducts);
        $products=$rproducts;
        return view('ProductDetail',compact('product', 'categories','rcategory', '$rproducts','products' ,'category'));
    }
}
