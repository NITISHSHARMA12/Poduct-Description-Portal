<?php

namespace App\Http\Controllers\Frontend;

use App\Category;
use App\Http\Requests\UserRequest;
use App\Product;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function index(){
        $categories=Category::Latest()->take(3)->get();
        $products=Product::all();
        $recentProduct=Product::Latest()->get();
        return view('home',compact('categories','products', 'recentProduct'));
    }
}
