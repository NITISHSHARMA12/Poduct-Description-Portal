<?php
namespace App\Http\Controllers\Frontend;
use App\Category;
use App\Product;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;


class CategoriesController extends Controller
{
    public function index(Request $request)
    {
        $sortby = '';
        if ($request->has('sortby')) {
            $sortby = $request->get('sortby');
        }
        $categories=Category::all();
        $size = $request->get('size', getenv('LIST_SIZE'));
        $data = $request->all();
        $products = Product::with('categories')->search($data)->priceOrder($sortby)->paginate($size);
        $recentproducts=Product::with('categories')->get();
        $request=$request->all();
        return view('layouts.partial.frontend.Filter.ProductSearch' ,compact('categories','products' ,'request' ,'recentproducts','sortby'));
    }

    public function show($id, Request $request)
    {
        $sortby = '';
        if ($request->has('sortby')) {
            $sortby = $request->get('sortby');
        }

        $category= Category::where('id', $id)->firstOrFail();
        $products = $category->product()->with('categories')->search($request->all())->get();
        $categories=Category::all();
        $request = $request->all();
        $request['cats'] = [$category->id];
//        $recentproducts=$products->latest()->get();
        $recentproducts=Product::with('categories')->get();
        return view('layouts.partial.frontend.Filter.ProductSearch' ,compact('categories','products','request','recentproducts','sortby'));
    }

}