<?php

namespace App\Http\Controllers\Frontend;

use App\Category;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class PageController extends Controller
{
//    public function contact(){
//        $categories=category::all();
//        return view('layouts.partial.Frontend.contact',compact('categories'));
//    }
}
