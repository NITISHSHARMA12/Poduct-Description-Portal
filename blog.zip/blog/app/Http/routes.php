<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
//Route::resource('home', 'CategoriesController');
//Route::get('/', 'HomeController@index');
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/
Route::get('/',['as' => 'home', 'uses' => 'Frontend\HomeController@index']);
Route::get('contact_us',['as' => 'contact', 'uses' => 'EnquiryController@contact']);
Route::post('contact_us/send',['as' => 'contact.send', 'uses' => 'EnquiryController@user']);
Route::get('query/{id}',['as' => 'query', 'uses' => 'EnquiryController@query']);
Route::post('query/send',['as' => 'query.send', 'uses' => 'EnquiryController@QuerySend']);
Route::get('product/{id}',['as' => 'frontend.products.show', 'uses' => 'Frontend\ProductController@show']);
Route::get('/categories', ['as' => 'frontend.categories.search', 'uses' => 'Frontend\CategoriesController@index']);
Route::get('/categories/{id}', ['as' => 'frontend.categories.show', 'uses' => 'Frontend\CategoriesController@show']);

Route::group(['middleware' => 'web'], function () {
    Route::auth();

Route::get('/auth', 'HomeController@index');
Route::resource('products', 'ProductController');
Route::resource('home', 'CategoriesController');
    /*
Route::get('register/{confirm_token}', ['as' => 'Confirm', 'uses' => 'AuthController@getEmailConfirmation']);
    */
});