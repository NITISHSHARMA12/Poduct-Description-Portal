<?php

namespace App;

use App\ModelTraits\PhotoFunctions;
use Illuminate\Database\Eloquent\Model;

class Photo extends Model
{
    use PhotoFunctions;

    protected $table = 'photos';
    protected $fillable = ['name', 'slug', 'path', 'desc'];

}