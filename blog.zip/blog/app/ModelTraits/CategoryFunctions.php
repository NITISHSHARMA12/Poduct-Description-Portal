<?php

namespace App\ModelTraits;

trait CategoryFunctions
{
    public function scopeSearch($query, $data)
    {
        return $query->where(function ($query) use ($data) {
            if (!empty($data['id'])) {
                $query->where('id', $data['id']);
            }
            if (!empty($data['name'])) {
                $query->where('name', 'like', $data['name'] . '%');
            }
            if (!empty($data['slug'])) {
                $query->where('slug', 'like', $data['slug'] . '%');
            }
            if (!empty($data['body'])) {
                $query->where('body', $data['body']);
            }
        });
    }

}
