<?php
namespace App\ModelTraits;
trait PhotoFunctions{
    public function scopeSearch($query, $data)
    {
        return $query->where(function($query) use($data){
            if(!empty($data['id'])){
                $query->where('id' , $data['id']);
            }
            if(!empty($data['name'])){
                $query->where('name' , $data['name'] . '%');
            }
            if(!empty($data['slug'])){
                $query->where('slug' , $data['slug'] . '%');
            }
            if(!empty($data['path'])){
                $query->where('path' , $data['path'] . '%');
            }
            if(!empty($data['desc'])){
                $query->where('desc' , $data['desc'] . '%');
            }
        });
    }

}