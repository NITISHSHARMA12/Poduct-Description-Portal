<?php

namespace App\ModelTraits;

trait ProductFunctions
{
    public function getCategoriesIdsAttribute()
    {
        return $this->Categories()->lists('id')->toArray();
    }
    public function scopeSearch($query, $data)
    {
        return $query->where(function ($query) use ($data) {
            if (!empty($data['id'])) {
                $query->where('id', $data['id']);
            }
            if (!empty($data['name'])) {
                $query->where('name', 'like', $data['name'] . '%');
            }
            if (!empty($data['slug'])) {
                $query->where('slug', 'like', $data['slug'] . '%');
            }
            if (!empty($data['body'])) {
                $query->where('body', $data['body']);
            }
            if (!empty($data['price'])) {
                $query->where('price', $data['price']);
            }
            if (!empty($data['discount'])) {
                $query->where('discount', $data['discount']);
            }
            if (!empty($data['short_desc'])) {
                $query->where('short_desc', $data['short_desc']);
            }
            if (!empty($data['long_desc'])) {
                $query->where('long_desc', $data['long_desc']);
            }
            if (!empty($data['cats'])) {
                $cats = $data['cats'];
                if(!empty($cats)) {
                    $query->whereHas('categories', function($query) use($cats){
                        $query->whereIn('id', $cats);
                    });
                }
            }
        });
    }
    public function scopePriceOrder($query, $data)
    {
        if (!empty($data)) {
            $sort = explode(' ', $data);
            $query->orderBy($sort[0], $sort[1]);
        }
        return $query;
    }

}
