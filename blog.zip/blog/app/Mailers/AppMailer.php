<?php


namespace App\Mailers;

use Illuminate\Contracts\Mail\Mailer;


class AppMailer {

    protected $mailer;
    protected $from;
    protected $to;
    protected $view;
    protected $data = [];

    public function __construct(Mailer $mailer)
    {
        $this->mailer = $mailer;
        $this->from = getenv('ADMIN_EMAIL');
    }

    public function deliver()
    {
        $this->mailer->send($this->view, $this->data, function ($message){
            $message->from($this->from, getenv('ADMIN_NAME'))
                ->to($this->to);
        });
    }


} 