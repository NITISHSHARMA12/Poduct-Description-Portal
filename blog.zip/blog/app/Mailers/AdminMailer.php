<?php

namespace App\Mailers;


class AdminMailer extends AppMailer
{

    public function sendUserData($data)
    {
        $this->to = getenv('ADMIN_EMAIL');
        $this->view = 'layouts.Email.layout';
        $this->data = compact('data');
        return $this;
    }
    public function sendUserProductData($data)
    {
        $this->to = getenv('ADMIN_EMAIL');
        $this->view = 'layouts.Email.ProductQuery';
        $this->data = compact('data');
        return $this;
    }

} 