<?php
namespace App\Mailers;
use App\Mailers\AppMailer;
use Illuminate\Foundation\Auth\User;

class UserMailer extends AppMailer{
    public function sendEmailConfirmationTo(User $user)
    {
        //dd($user);
        $this->to = $user->email;
        $this->view = 'emails.confirm';
        $this->data = compact('user');
        return $this;
    }
}