<?php

namespace App;

use App\ModelTraits\CategoryFunctions;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use CategoryFunctions;

    protected $table = 'categories';

    protected $fillable = ['name','slug','body','thumbnail'];


    public function saveThumbnail($file)
    {
        if (isset($file)) {
            $name = strtolower('thumbnail-' . $file->getClientOriginalName());
            $folder = "uploads/category/" . $this->id;
            $file->move($folder . "/", $name);
            $this->thumbnail = "$folder/$name";
            $this->save();
        }
    }
    public function product()
    {
        return $this->belongsToMany(Product::class);
    }
}
