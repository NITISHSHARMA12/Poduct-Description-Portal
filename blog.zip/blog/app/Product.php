<?php

namespace App;

use App\ModelTraits\ProductFunctions;
use Illuminate\Database\Eloquent\Model;
use App\Category;

class Product extends Model
{
    use ProductFunctions;

    protected $table = 'products';

    protected $fillable = ['p_id','name','slug','category','inventory','short_desc','long_desc','price','discount','thumbnail'];

    public function saveThumbnail($file)
    {
        if (isset($file)) {
            $name = strtolower('thumbnail-' . $file->getClientOriginalName());
            $folder = "uploads/product/" . $this->id;
            $file->move($folder . "/", $name);
            $this->thumbnail = "$folder/$name";
            $this->save();
        }
    }
    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }

}
